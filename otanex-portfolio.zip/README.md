# iamnewbie Portfolio

This is the personal GitHub Pages portfolio site for `otanex` aka `iamnewbie`.

## Sections

- Home
- About
- Homelab
- Projects

Visit the live site: [https://otanex.github.io](https://otanex.github.io)
